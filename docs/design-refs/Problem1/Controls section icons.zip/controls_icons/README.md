# Account page — CONTROLS section icons

10 SVGs exported from the Account page CONTROLS block.

| File | Row | viewBox | Rendered size in design |
|---|---|---|---|
| controls-header-gear.svg | CONTROLS section header | 0 0 24 24 | 26 x 26 |
| account-details.svg | Account details | 0 0 24 24 | 19 x 19 |
| verification.svg | Verification | 0 0 24 24 | 19 x 19 |
| security.svg | Security | 0 0 24 24 | 19 x 19 |
| preferences.svg | Preferences | 0 0 24 24 | 19 x 19 |
| affiliate-program.svg | Affiliate program | 0 0 24 24 | 19 x 19 |
| responsible-gaming.svg | Responsible gaming | 0 0 24 24 | 19 x 19 |
| blocked-players.svg | Blocked players | 0 0 24 24 | 19 x 19 |
| help-support.svg | Help & support | 0 0 24 24 | 19 x 19 |
| chevron-right.svg | Right-hand triangle (all rows) | 0 0 8 12 | 8 x 12 |

## Colors

Fills reference CSS custom properties with hardcoded fallbacks, so the files work
with or without the RapidClash token set defined on an ancestor:

- `--rc-muted` (fallback `#83838F`) — icon body and the chevron
- `--rc-surface` (fallback `#1A1A2E`) — knockout / cutout shapes, matches the row card background
- `--rc-sunken` (fallback `#0B0B0B`) — gear centre hole
- `--rc-purple` (fallback `#8B45F0`) — CONTROLS header gear only

Light-mode values: `--rc-muted: #6E6E7A`, `--rc-surface: #E9E9F0`, `--rc-sunken: #D3D3DD`.

Note the cutouts are painted, not transparent — they must match the surface
behind the icon. Set `--rc-surface` to the actual row background if it differs.

`preview.html` renders all ten on the dark surface for reference.
